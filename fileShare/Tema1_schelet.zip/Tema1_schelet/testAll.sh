#!/bin/bash

./test1.sh 0
./test2.sh 0
./test3.sh 0

./test1.sh 50 parity
./test2.sh 50 parity
./test3.sh 50 parity

./test1.sh 100 hamming
./test2.sh 100 hamming
./test3.sh 100 hamming
